from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
import MySQLdb.cursors
from PIL import Image
import mysql.connector
from datetime import datetime
import io
# import torch
# from torch import torchvision 
# import pixellib
# from pixellib.instance import instance_segmentation
from pixellib.torchbackend.instance import instanceSegmentation


mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password='12345',
    database='Image_segmentation'
)


app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files["image"]
    print(type(file),file)
    if file:
        img = Image.open(file.stream)
        #filename
        filename=file.filename
        # list=filename.split(".")
        # print(filename,list)
        # ext=list[len(list)-1]
        cur_time=datetime.now()
        m=str(cur_time)
        m=m.replace("-","")
        m=m.replace(" ","")
        m=m.replace(".","")
        m=m.replace(":","")
        img_name=m+"_"+filename
        
        img.save("static/images/"+img_name)
        print("Input data stored successfully.")
        
        ins = instanceSegmentation()
        ins.load_model("pointrend_resnet50.pkl", detection_speed = "fast")
        ins.segmentImage("static/images/"+img_name, show_bboxes=True,text_size=0.6, text_thickness=1, box_thickness=1, output_image_name="static/images/seg_"+img_name)

        
        # segment_image.segmentBatch("static/images/"+img_name, show_bboxes=True, output_image_name="static/images/"+"seg_"+img_name)
        
        # img_mirror = img.transpose(Image.FLIP_LEFT_RIGHT)
        # img_mirror.save("static/images/seg_" + img_name)
        
        return redirect(url_for("result", filename=img_name))
    else:
        return redirect(url_for("index.html"))


@app.route("/result/<filename>", methods=["POST","GET"])
def result(filename):
    
    mycursor = mydb.cursor()
    path1="static/images/"+filename
    path2="static/images/seg_"+filename
    sql = "INSERT INTO Images (input_image,Output_image) VALUES ('"+path1+"','"+path2+"')"
    print(sql)
    mycursor.execute(sql)
    mycursor.execute("SELECT id FROM images ORDER BY id DESC LIMIT 1")
    result = mycursor.fetchone()
    row_id=result[0]
    print(row_id)
    mydb.commit()
    print("Output data stored successfully.")

    return render_template("result.html", filename=filename,row_id=row_id)

@app.route("/acceptable", methods=["POST","GET"])
def acceptable():
    
    mycursor = mydb.cursor()
    mycursor.execute("SELECT id,input_image FROM images ORDER BY id DESC LIMIT 1")
    result = mycursor.fetchone()
    row_id=result[0]
    filename=result[1]
    # UPDATE employees
    # SET name = 'John Smith'
    # WHERE id = 123;
    sql = "update Images set status = '"+"acceptable"+"' where id = "+str(row_id)
    print(sql)
    mycursor.execute(sql) 
    mydb.commit()
    print("Status updated successfully.")

    return render_template("index.html")

@app.route("/unacceptable", methods=["POST","GET"])
def unacceptable():  
    mycursor = mydb.cursor() 
    mycursor.execute("SELECT id,input_image FROM images ORDER BY id DESC LIMIT 1")
    result = mycursor.fetchone()
    row_id=result[0]
    filename=result[1]
    sql = "update Images set status = '"+"unacceptable"+"' where id = "+str(row_id)
    print(sql)
    mycursor.execute(sql)   
    mydb.commit()
    print("Status updated successfully.")

    return render_template("index.html")


#return "Image processed successfully."


if __name__ == '__main__':
    app.run(debug=True)   