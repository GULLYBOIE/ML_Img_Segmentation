# import pixellib
import time
s=time.time()
from pixellib.torchbackend.instance import instanceSegmentation


start=time.time()
print(start-s)
ins = instanceSegmentation()
ins.load_model("pointrend_resnet50.pkl", detection_speed = "fast")
ins.segmentImage("images/cycle.jpg", show_bboxes=True,text_size=0.6, text_thickness=1, box_thickness=1, output_image_name="seg_images/seg_cycle.jpg")
# ins.segmentImage("images/cycle.jpg", show_bboxes=True,text_size=5, text_thickness=3, box_thickness=8, output_image_name="seg_images/seg_cycle.jpg")

end=time.time()
print(end)
duration=end-start
print(duration)