-- CREATE DATABASE Image_segmentation;
use Image_segmentation;
CREATE TABLE images (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    input_image VARCHAR(255) NOT NULL,
    output_image VARCHAR(255) NOT NULL,
    status ENUM('pending', 'acceptable', 'unacceptable') NOT NULL DEFAULT 'pending'
);
-- alter table images add column status ENUM('pending', 'acceptable', 'unacceptable') NOT NULL DEFAULT 'pending';
-- ALTER TABLE  images DROP COLUMN Output_image;
-- delete from images where id = 1;
-- select * from images; 
INSERT INTO images( file_path, status) 
--   value ('D:\Internship\Image_segmentation','unacceptable');